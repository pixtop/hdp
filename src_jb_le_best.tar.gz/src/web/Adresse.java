package web;

import java.util.Collection;

import javax.persistence.*;

@Entity
public class Adresse {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	private String rue;
	
	private String ville;
	
	@ManyToMany(mappedBy="adresses")
	private Collection<Personne> personnes;
	
	Adresse() {}
	
	Adresse(String r, String v) {
		this.rue = r;
		this.ville = v;
	}
	
	public int getId() {
		return this.id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getRue() {
		return this.rue;
	}
	
	public void setRue(String r) {
		this.rue = r;
	}
	
	public String getVille() {
		return this.ville;
	}
	
	public void setVille(String v) {
		this.ville = v;
	}
	
	public Collection<Personne> getPersonnes() {
		return this.personnes;
	}
}

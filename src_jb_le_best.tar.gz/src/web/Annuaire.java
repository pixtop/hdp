package web;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Annuaire
 */
@WebServlet("/Annuaire")

public class Annuaire extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@EJB
	private Facade f;

    /**
     * Default constructor. 
     */
    public Annuaire() {
    	super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String route = request.getParameter("op");
		request.setAttribute("valide", false);
		switch (route) {
			case "personne":
				request.getRequestDispatcher("ajouter.jsp").forward(request, response);
				break;
			case "adresse":
				request.getRequestDispatcher("ajouter.jsp").forward(request, response);
				break;
			case "afficher":
				request.setAttribute("personnes", f.listePersonnes());
				request.setAttribute("adresses", f.listeAdresses());
				request.getRequestDispatcher("afficher.jsp").forward(request, response);
				break;
			case "associer":
				request.setAttribute("personnes", f.listePersonnes());
				request.setAttribute("adresses", f.listeAdresses());
				request.getRequestDispatcher("associer.jsp").forward(request, response);
				break;
			default:
				request.getRequestDispatcher("404.html").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String route = request.getParameter("op");
		request.setAttribute("valide", false);
		switch(route) {
			case "personne":
				if (request.getParameter("nom") != null && request.getParameter("prenom") != null) {
					f.ajoutPersonne(request.getParameter("nom"), request.getParameter("prenom"));
					request.setAttribute("valide", true);
				}
				request.getRequestDispatcher("ajouter.jsp").forward(request, response);
				break;
			case "adresse":
				if (request.getParameter("rue") != null && request.getParameter("ville") != null) {
					f.ajoutAdresse(request.getParameter("rue"), request.getParameter("ville"));
					request.setAttribute("valide", true);
				}
				request.getRequestDispatcher("ajouter.jsp").forward(request, response);
				break;
			case "associer":
				if (request.getParameter("personne") != null && request.getParameter("adresse") != null) {
					f.associer(Integer.parseInt(request.getParameter("personne")), Integer.parseInt(request.getParameter("adresse")));
					request.setAttribute("valide", true);
				}
				request.setAttribute("personnes", f.listePersonnes());
				request.setAttribute("adresses", f.listeAdresses());
				request.getRequestDispatcher("associer.jsp").forward(request, response);
				break;
			default:
				doGet(request, response);
		}	
	}

}

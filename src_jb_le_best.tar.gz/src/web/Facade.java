package web;

import java.util.Collection;

import javax.ejb.Singleton;
import javax.persistence.*;

@Singleton
public class Facade {
	
	@PersistenceContext
	private EntityManager em;
	
	Facade() {}
	
	public void ajoutPersonne(String nom, String prenom) {
		this.em.persist(new Personne(nom, prenom));
	}
	
	public void ajoutAdresse(String rue, String ville) {
		this.em.persist(new Adresse(rue, ville));
	}
	
	public Collection<Personne> listePersonnes() {
		TypedQuery<Personne> req = this.em.createQuery("SELECT p FROM Personne p", Personne.class);
		return req.getResultList();
	}

	public Collection<Adresse> listeAdresses() {
		TypedQuery<Adresse> req = this.em.createQuery("SELECT a FROM Adresse a", Adresse.class);
		return req.getResultList();
	}
	
	public void associer(int personneId, int adresseId) {
		Personne p = this.em.find(Personne.class, personneId);
		Adresse a = this.em.find(Adresse.class, adresseId);
		p.getAdresses().add(a);
	}
}

package web;

import java.util.Collection;

import javax.persistence.*;

@Entity
public class Personne {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	private String nom;
	
	private String prenom;

	@ManyToMany(fetch=FetchType.EAGER)
	private Collection<Adresse> adresses;
	
	Personne() {}
	
	Personne(String n, String p) {
		this.nom = n;
		this.prenom = p;
	}
	
	public int getId() {
		return this.id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getNom() {
		return this.nom;
	}
	
	public void setNom(String n) {
		this.nom = n;
	}
	
	public String getPrenom() {
		return this.prenom;
	}
	
	public void setPrenom(String p) {
		this.prenom = p;
	}
	
	public Collection<Adresse> getAdresses() {
		return this.adresses;
	}
}
